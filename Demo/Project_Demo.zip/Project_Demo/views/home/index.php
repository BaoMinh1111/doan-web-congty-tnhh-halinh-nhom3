<?php $pageTitle = $pageTitle ?? 'Trang chủ'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> — Project Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
        <div class="container-fluid">
            <a class="navbar-brand" href="/">Project Demo</a>
            <div class="navbar-nav">
                <a class="nav-link" href="/admin/products">Admin Products</a>
                <a class="nav-link" href="/cart">Cart</a>
            </div>
        </div>
    </nav>

    <h1><?php echo htmlspecialchars($pageTitle); ?></h1>
    
    <?php if (isset($currentCategory)): ?>
        <p>Filtering by category: <?php echo htmlspecialchars($currentCategory->getName()); ?> (ID: <?php echo $categoryId; ?>)</p>
    <?php else: ?>
        <h2>All Products</h2>
<p>Total products: <?php echo isset($products) ? count($products) : 0; ?></p>
        <?php if (isset($featured)): ?>
<h3>Featured (<?php echo isset($featured) ? count($featured) : 0; ?>)</h3>
        <?php endif; ?>
    <?php endif; ?>

    <div class="row">
<?php if (isset($products) && is_array($products)): foreach ($products as $item): $product = $item['product']; $category = $item['category'] ?? null; ?>
        <div class="col-md-4 mb-3">
            <div class="card">
                <?php if ($product->getImage()): ?>
                    <img src="<?php echo htmlspecialchars($product->getImage()); ?>" class="card-img-top" alt="<?php echo htmlspecialchars($product->getName()); ?>">
                <?php endif; ?>
                <div class="card-body">
                    <h5 class="card-title"><?php echo htmlspecialchars($product->getName()); ?></h5>
                    <p class="card-text"><?php echo number_format($product->getPrice(), 0, ',', '.'); ?> VNĐ</p>
                    <?php if ($category): ?>
                        <p class="card-text"><small class="text-muted">Category: <?php echo htmlspecialchars($category->getName()); ?></small></p>
                    <?php endif; ?>
                    <a href="/product/detail?id=<?php echo $product->getId(); ?>" class="btn btn-primary">Detail</a>
                </div>
            </div>
        </div>
<?php endforeach; endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

