<?php

class HomeController extends BaseController
{
    private ProductService $productService;

    public function __construct(ProductService $productService)
    {
        parent::__construct();
        $this->productService = $productService;
    }

    public function index(): void
    {
        $categoryId = $this->get('category_id', 0);
        $categories = $this->productService->getAllCategories();

        if ($categoryId > 0) {
            $currentCategory = $this->productService->getCategoryById($categoryId);

            if ($currentCategory === null) {
                $this->redirect('/');
                return;
            }

            $products  = $this->productService->getByCategory($categoryId);
            $featured  = null;
            $pageTitle = $currentCategory->getName() . ' - Ha Linh Tech';
        } else {
            $products        = $this->productService->getProductsWithCategory();
            $featured        = $this->productService->getFeatured(8);
            $currentCategory = null;
            $pageTitle       = 'Trang chu - Ha Linh Tech';
        }

        $this->renderView('home/index', [
            'products'        => $products,
            'featured'        => $featured,
            'categories'      => $categories,
            'currentCategory' => $currentCategory,
            'categoryId'      => $categoryId,
            'pageTitle'       => $pageTitle,
        ]);
    }
}
