<?php

class ProductController extends BaseController
{
    private ProductService $productService;

    public function __construct(ProductService $productService)
    {
        parent::__construct();
        $this->productService = $productService;
    }

    public function detail(): void
    {
        if (!$this->isGet()) {
            $this->redirect('/');
            return;
        }

        $id = $this->get('id', 0);

        if ($id <= 0) {
            $this->redirect('/?error=invalid_product');
            return;
        }

        $detail = $this->productService->getProductDetail($id);

        if ($detail === null) {
            $this->redirect('/?error=product_not_found');
            return;
        }

        $categories = $this->productService->getAllCategories();

        $this->renderView('product/detail', [
            'product'    => $detail['product'],
            'category'   => $detail['category'],
            'categories' => $categories,
            'pageTitle'  => $detail['product']->getName() . ' - Ha Linh Tech',
        ]);
    }

    public function search(): void
    {
        if (!$this->isGet()) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Phuong thuc khong hop le. Chi chap nhan GET.',
            ], 405);
            return;
        }

        $keyword    = trim($this->get('q', ''));
        $categoryId = $this->get('category_id', 0);

        if (mb_strlen($keyword) > 100) {
            $this->jsonResponse([
                'success' => false,
                'message' => 'Tu khoa khong duoc vuot qua 100 ky tu.',
            ], 400);
            return;
        }

        $results = [];

        try {
            if ($keyword === '' && $categoryId <= 0) {
                $results = [];
            } elseif ($keyword === '' && $categoryId > 0) {
                $results = $this->productService->getByCategory($categoryId);
            } else {
                $results = $this->productService->searchAndFilter($keyword, $categoryId);
            }
        } catch (Throwable $e) {
            error_log('[ProductController::search] ' . $e->getMessage());
            $this->jsonResponse([
                'success' => false,
                'message' => 'Da co loi xay ra trong qua trinh tim kiem. Vui long thu lai.',
            ], 500);
            return;
        }

        $data = array_map(fn(array $item) => [
            'product'  => $item['product']->toArray(),
            'category' => $item['category']?->toArray(),
        ], $results);

        $this->jsonResponse([
            'success'     => true,
            'keyword'     => $keyword,
            'category_id' => $categoryId,
            'total'       => count($data),
            'data'        => $data,
        ]);
    }
}
