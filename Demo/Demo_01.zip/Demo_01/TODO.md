# Fix Project to Run

Status: In progress

## Steps:

- [ ] 1. Fix bootstrap.php paths (remove /app/)
- [ ] 2. Create config/database.php (sample creds)
- [ ] 3. Create helpers/AdminMiddleware.php (stub)
- [ ] 4. Create views/home/index.php (minimal)
- [ ] 5. Fix redirects in controllers (add return;)
- [ ] 6. Delete duplicate AdminController_1.php
- [ ] 7. Test & complete
