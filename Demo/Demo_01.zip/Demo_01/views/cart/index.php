<?php $pageTitle = $pageTitle ?? 'Gio hang'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
    <h1 class="h4 mb-3">Gio hang</h1>
    <a href="/" class="btn btn-link p-0 mb-3">&larr; Ve trang chu</a>

    <?php if (empty($cart)): ?>
        <div class="alert alert-info">Gio hang dang trong.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>San pham</th>
                        <th>Gia</th>
                        <th>So luong</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cart as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['name'] ?? ('SP #' . ($item['product_id'] ?? ''))); ?></td>
                            <td><?php echo number_format((float) ($item['price'] ?? 0), 0, ',', '.'); ?> VND</td>
                            <td><?php echo (int) ($item['quantity'] ?? 0); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <div class="mt-3">
        <strong>Tong tam tinh:</strong>
        <?php echo number_format((float) (($total['data']['total'] ?? 0)), 0, ',', '.'); ?> VND
    </div>
</body>
</html>
