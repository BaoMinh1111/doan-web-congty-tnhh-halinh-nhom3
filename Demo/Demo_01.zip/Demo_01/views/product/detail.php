<?php $pageTitle = $pageTitle ?? 'Chi tiet san pham'; ?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
    <a href="/" class="btn btn-link p-0 mb-3">&larr; Ve trang chu</a>
    <div class="card">
        <div class="card-body">
            <h1 class="h4"><?php echo htmlspecialchars($product->getName()); ?></h1>
            <p class="mb-1"><strong>Gia:</strong> <?php echo number_format($product->getPrice(), 0, ',', '.'); ?> VND</p>
            <p class="mb-1"><strong>Danh muc:</strong> <?php echo htmlspecialchars($category?->getName() ?? 'Khong ro'); ?></p>
            <p class="mb-0"><strong>Mo ta:</strong> <?php echo nl2br(htmlspecialchars($product->getDescription())); ?></p>
        </div>
    </div>
</body>
</html>
