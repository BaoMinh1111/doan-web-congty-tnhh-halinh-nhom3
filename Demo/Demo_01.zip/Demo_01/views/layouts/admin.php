<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($title ?? 'Admin'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-4">
    <nav class="mb-4 d-flex gap-3">
        <a href="/">Trang chu</a>
        <a href="/admin/dashboard">Dashboard</a>
        <a href="/admin/products">San pham</a>
        <a href="/cart">Cart</a>
    </nav>

    <?php echo $content ?? ''; ?>
</body>
</html>
