<?php
$pageTitle = $pageTitle ?? 'Trang chu';
$products = (isset($products) && is_array($products)) ? $products : [];
$totalProducts = count($products);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($pageTitle); ?> - Project Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .product-card {
            height: 100%;
        }

        .product-image,
        .product-placeholder {
            height: 220px;
            object-fit: cover;
        }

        .product-placeholder {
            background: #f1f3f5;
            color: #6c757d;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }
    </style>
</head>
<body class="container py-5">
    <nav class="navbar navbar-expand-lg navbar-light bg-light mb-4 rounded px-3">
        <div class="container-fluid">
            <a class="navbar-brand" href="/">Project Demo</a>
            <div class="navbar-nav">
                <a class="nav-link" href="/admin/products">Admin Products</a>
                <a class="nav-link" href="/cart">Cart</a>
            </div>
        </div>
    </nav>

    <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
        <h1 class="h3 mb-0"><?php echo htmlspecialchars($pageTitle); ?></h1>
        <span class="badge text-bg-primary fs-6">Tong san pham: <?php echo $totalProducts; ?></span>
    </div>

    <?php if (!empty($currentCategory)): ?>
        <div class="alert alert-info">
            Dang loc theo danh muc: <strong><?php echo htmlspecialchars($currentCategory->getName()); ?></strong>
        </div>
    <?php endif; ?>

    <?php if ($totalProducts === 0): ?>
        <div class="alert alert-warning mb-0">
            Chua co san pham de hien thi. Vui long kiem tra ket noi MySQL va bang <code>products</code>.
        </div>
    <?php else: ?>
        <div class="row g-3">
            <?php foreach ($products as $item): ?>
                <?php
                $product = $item['product'];
                $category = $item['category'] ?? null;
                $image = trim((string) $product->getImage());
                ?>
                <div class="col-12 col-md-6 col-lg-4">
                    <div class="card shadow-sm product-card">
                        <?php if ($image !== ''): ?>
                            <img src="<?php echo htmlspecialchars($image); ?>" class="card-img-top product-image" alt="<?php echo htmlspecialchars($product->getName()); ?>">
                        <?php else: ?>
                            <div class="product-placeholder">NO IMAGE</div>
                        <?php endif; ?>
                        <div class="card-body d-flex flex-column">
                            <h2 class="h5 card-title"><?php echo htmlspecialchars($product->getName()); ?></h2>
                            <p class="card-text text-danger fw-semibold mb-2">
                                <?php echo number_format($product->getPrice(), 0, ',', '.'); ?> VND
                            </p>
                            <?php if ($category !== null): ?>
                                <p class="card-text text-muted mb-3">Danh muc: <?php echo htmlspecialchars($category->getName()); ?></p>
                            <?php endif; ?>
                            <a href="/product/detail?id=<?php echo $product->getId(); ?>" class="btn btn-primary mt-auto">Xem chi tiet</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
