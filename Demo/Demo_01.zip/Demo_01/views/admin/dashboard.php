<h1 class="h4 mb-3">Dashboard</h1>
<div class="row g-3 mb-3">
    <div class="col-md-3"><div class="card"><div class="card-body">Tong SP: <strong><?php echo (int) $totalProducts; ?></strong></div></div></div>
    <div class="col-md-3"><div class="card"><div class="card-body">Tong don: <strong><?php echo (int) $totalOrders; ?></strong></div></div></div>
    <div class="col-md-3"><div class="card"><div class="card-body">Doanh thu thang: <strong><?php echo number_format((float) $revenueMonth, 0, ',', '.'); ?> VND</strong></div></div></div>
    <div class="col-md-3"><div class="card"><div class="card-body">Sap het hang: <strong><?php echo count($lowStockProducts ?? []); ?></strong></div></div></div>
</div>
