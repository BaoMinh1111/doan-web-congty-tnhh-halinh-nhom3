<h1 class="h4 mb-3"><?php echo htmlspecialchars($formTitle ?? 'Form san pham'); ?></h1>
<form method="post" class="row g-3" enctype="multipart/form-data">
    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($csrf_token ?? ''); ?>">
    <div class="col-md-6">
        <label class="form-label">Ten san pham</label>
        <input class="form-control" name="name" value="<?php echo htmlspecialchars($old['name'] ?? $product?->getName() ?? ''); ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Gia</label>
        <input class="form-control" type="number" step="0.01" name="price" value="<?php echo htmlspecialchars((string) ($old['price'] ?? $product?->getPrice() ?? 0)); ?>" required>
    </div>
    <div class="col-md-3">
        <label class="form-label">Ton kho</label>
        <input class="form-control" type="number" name="stock" value="<?php echo htmlspecialchars((string) ($old['stock'] ?? $product?->getStock() ?? 0)); ?>" required>
    </div>
    <div class="col-md-6">
        <label class="form-label">Danh muc</label>
        <select class="form-select" name="category_id" required>
            <option value="">-- Chon danh muc --</option>
            <?php $currentCategory = (int) ($old['category_id'] ?? $product?->getCategoryId() ?? 0); ?>
            <?php foreach (($categories ?? []) as $cat): ?>
                <option value="<?php echo $cat->getId(); ?>" <?php echo $currentCategory === $cat->getId() ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($cat->getName()); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-6">
        <label class="form-label">Anh</label>
        <input class="form-control" type="file" name="image" accept="image/*">
    </div>
    <div class="col-12">
        <label class="form-label">Mo ta</label>
        <textarea class="form-control" name="description" rows="4"><?php echo htmlspecialchars($old['description'] ?? $product?->getDescription() ?? ''); ?></textarea>
    </div>
    <div class="col-12">
        <button class="btn btn-primary" type="submit">Luu</button>
        <a class="btn btn-secondary" href="/admin/products">Huy</a>
    </div>
</form>
