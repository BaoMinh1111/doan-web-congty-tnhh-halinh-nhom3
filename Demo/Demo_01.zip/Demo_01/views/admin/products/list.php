<h1 class="h4 mb-3">Danh sach san pham</h1>
<a class="btn btn-primary btn-sm mb-3" href="/admin/products/add">Them san pham</a>

<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ten</th>
                <th>Danh muc</th>
                <th>Gia</th>
                <th>Ton</th>
                <th>Thao tac</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($products as $item): $p = $item['product']; $c = $item['category']; ?>
                <tr>
                    <td><?php echo $p->getId(); ?></td>
                    <td><?php echo htmlspecialchars($p->getName()); ?></td>
                    <td><?php echo htmlspecialchars($c?->getName() ?? '-'); ?></td>
                    <td><?php echo number_format($p->getPrice(), 0, ',', '.'); ?></td>
                    <td><?php echo (int) ($p->getStock() ?? 0); ?></td>
                    <td>
                        <a class="btn btn-sm btn-outline-primary" href="/admin/products/edit?id=<?php echo $p->getId(); ?>">Sua</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
