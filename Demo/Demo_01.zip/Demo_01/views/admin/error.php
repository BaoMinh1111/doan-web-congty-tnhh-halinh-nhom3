<div class="alert alert-danger">
    <?php echo htmlspecialchars($errorMessage ?? 'Da xay ra loi he thong.'); ?>
</div>
