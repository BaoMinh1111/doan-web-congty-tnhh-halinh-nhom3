<?php

require_once __DIR__ . '/bootstrap.php';

$uri = strtok($_SERVER['REQUEST_URI'] ?? '/', '?');
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if ($uri !== '/' && str_ends_with($uri, '/')) {
    $uri = rtrim($uri, '/');
}

if (str_starts_with($uri, '/index.php')) {
    $uri = substr($uri, 10);
    $uri = $uri === '' ? '/' : $uri;
}

if (AdminMiddleware::isAdminRoute($uri)) {
    AdminMiddleware::handle();
}

function makeProductService(): ProductService
{
    return new ProductService(new ProductModel(), new CategoryModel());
}

function makeOrderService(): OrderService
{
    return new OrderService(
        new OrderModel(),
        new OrderDetailModel(),
        new ProductModel(),
        new CustomerModel(),
        new InventoryModel(),
        new PromotionModel()
    );
}

function makeAdminController(): AdminController
{
    return new AdminController(
        makeProductService(),
        makeOrderService(),
        new AuthService(new UserModel())
    );
}

switch (true) {
    case $uri === '/' && $method === 'GET':
        (new HomeController(makeProductService()))->index();
        break;

    case $uri === '/product/detail' && $method === 'GET':
        (new ProductController(makeProductService()))->detail();
        break;

    case $uri === '/product/search' && $method === 'GET':
        (new ProductController(makeProductService()))->search();
        break;

    case $uri === '/cart' && $method === 'GET':
        (new CartController())->index();
        break;

    case $uri === '/cart/add' && $method === 'POST':
        (new CartController())->add();
        break;

    case $uri === '/cart/remove' && $method === 'POST':
        (new CartController())->remove();
        break;

    case $uri === '/cart/update' && $method === 'POST':
        (new CartController())->update();
        break;

    case $uri === '/cart/clear' && $method === 'POST':
        (new CartController())->clear();
        break;

    case $uri === '/cart/total' && $method === 'GET':
        (new CartController())->total();
        break;

    case ($uri === '/admin' || $uri === '/admin/dashboard') && $method === 'GET':
        makeAdminController()->dashboard();
        break;

    case $uri === '/admin/products' && $method === 'GET':
        makeAdminController()->manageProducts();
        break;

    case $uri === '/admin/products/add' && ($method === 'GET' || $method === 'POST'):
        makeAdminController()->addProduct();
        break;

    case $uri === '/admin/products/edit' && ($method === 'GET' || $method === 'POST'):
        makeAdminController()->editProduct();
        break;

    case $uri === '/admin/products/delete' && $method === 'POST':
        makeAdminController()->deleteProduct();
        break;

    case $uri === '/logout' && $method === 'GET':
        (new AuthService(new UserModel()))->logout();
        header('Location: /');
        exit;

    case $uri === '/login' && $method === 'GET':
        renderSimplePage('Dang nhap', '<p>Auth flow chua duoc implement day du trong du an nay.</p>');
        break;

    case $uri === '/403':
        http_response_code(403);
        renderSimplePage('403 Forbidden', '<h1>403 - Khong co quyen truy cap</h1><p><a href="/">Ve trang chu</a></p>');
        break;

    default:
        http_response_code(404);
        renderSimplePage('404 Not Found', '<h1>404 - Khong tim thay trang</h1><p><a href="/">Ve trang chu</a></p>');
        break;
}

function renderSimplePage(string $title, string $body): void
{
    echo "<!DOCTYPE html><html lang='vi'><head>
        <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
        <title>{$title} - Project Demo</title>
        <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css'>
    </head><body class='container py-4'>
        <nav class='mb-4'><a href='/'>Trang chu</a> | <a href='/admin/products'>Admin</a> | <a href='/cart'>Cart</a></nav>
        {$body}
    </body></html>";
}
