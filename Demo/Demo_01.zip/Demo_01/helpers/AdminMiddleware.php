<?php
/**
 * AdminMiddleware - Kiểm tra quyền admin cho routes /admin/*
 */
class AdminMiddleware {
    public static function isAdminRoute(string $uri): bool {
        return str_starts_with($uri, '/admin');
    }
    
    public static function handle(): void {
        if (!SessionHelper::isLoggedIn() || !SessionHelper::isAdmin()) {
            if (!SessionHelper::isLoggedIn()) {
                header('Location: /login');
            } else {
                header('Location: /403');
            }
            exit;
        }
    }
}
?>

