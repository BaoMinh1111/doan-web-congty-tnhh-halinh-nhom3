<?php

class DemoDataSeeder
{
    private const DEMO_IMAGE_FALLBACK = '/assets/demo/product-default.svg';

    public static function seedIfNeeded(): void
    {
        if (!defined('APP_ENV') || APP_ENV !== 'development') {
            return;
        }

        $db = Database::getInstance()->getConnection();

        if (!self::tableExists($db, 'categories') || !self::tableExists($db, 'products')) {
            return;
        }

        $categoryCount = self::countRows($db, 'categories');
        $productCount = self::countRows($db, 'products');

        if ($categoryCount > 0 && $productCount > 0) {
            return;
        }

        try {
            if (!$db->inTransaction()) {
                $db->beginTransaction();
            }

            self::ensureCategories($db, $categoryCount);
            self::ensureProducts($db, $productCount);
            self::normalizeProductImages($db);

            if ($db->inTransaction()) {
                $db->commit();
            }
        } catch (Throwable $e) {
            if ($db->inTransaction()) {
                $db->rollBack();
            }

            error_log('DemoDataSeeder failed: ' . $e->getMessage());
        }
    }

    private static function tableExists(PDO $db, string $table): bool
    {
        $stmt = $db->prepare(
            'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?'
        );
        $stmt->execute([$table]);
        return (int) $stmt->fetchColumn() > 0;
    }

    private static function countRows(PDO $db, string $table): int
    {
        $stmt = $db->query("SELECT COUNT(*) FROM {$table}");
        return (int) $stmt->fetchColumn();
    }

    private static function ensureCategories(PDO $db, int $currentCount): void
    {
        if ($currentCount > 0) {
            return;
        }

        $categories = [
            ['name' => 'Dien thoai', 'description' => 'Smartphone va phu kien di dong'],
            ['name' => 'Laptop', 'description' => 'Laptop cho hoc tap va cong viec'],
            ['name' => 'Tai nghe', 'description' => 'Tai nghe va loa bluetooth'],
            ['name' => 'Phu kien', 'description' => 'Sac, cap, chuot, ban phim'],
        ];

        $stmt = $db->prepare('INSERT INTO categories (name, description) VALUES (?, ?)');
        foreach ($categories as $category) {
            $stmt->execute([$category['name'], $category['description']]);
        }
    }

    private static function ensureProducts(PDO $db, int $currentCount): void
    {
        if ($currentCount > 0) {
            return;
        }

        $rows = $db->query('SELECT id, name FROM categories')->fetchAll(PDO::FETCH_ASSOC);
        if (empty($rows)) {
            return;
        }

        $categoryMap = [];
        $categoryIds = [];
        foreach ($rows as $row) {
            $categoryMap[$row['name']] = (int) $row['id'];
            $categoryIds[] = (int) $row['id'];
        }

        $products = [
            ['Dien thoai', 'iPhone 16 Pro 256GB', 30990000, '/assets/demo/phone-1.svg', 'Ban demo: chip A18, camera 48MP', 12],
            ['Dien thoai', 'Samsung Galaxy S25', 22990000, '/assets/demo/phone-2.svg', 'Ban demo: man hinh AMOLED 120Hz', 18],
            ['Laptop', 'MacBook Air M3 13 inch', 27990000, '/assets/demo/laptop-1.svg', 'Ban demo: pin lau, gon nhe', 7],
            ['Laptop', 'ASUS Vivobook 15', 14990000, '/assets/demo/laptop-2.svg', 'Ban demo: phu hop sinh vien', 20],
            ['Tai nghe', 'Sony WH-1000XM5', 7990000, '/assets/demo/audio-1.svg', 'Ban demo: chong on chu dong', 25],
            ['Tai nghe', 'JBL Tune 770NC', 2490000, '/assets/demo/audio-2.svg', 'Ban demo: nghe nhac 2 ngay lien tuc', 35],
            ['Phu kien', 'Sac nhanh GaN 65W', 890000, '/assets/demo/accessory-1.svg', 'Ban demo: sac laptop va dien thoai', 40],
            ['Phu kien', 'Ban phim co wireless', 1290000, '/assets/demo/accessory-2.svg', 'Ban demo: switch linear', 16],
        ];

        $stmt = $db->prepare(
            'INSERT INTO products (category_id, name, price, image, description, stock) VALUES (?, ?, ?, ?, ?, ?)'
        );

        foreach ($products as $index => [$categoryName, $name, $price, $image, $description, $stock]) {
            $categoryId = $categoryMap[$categoryName] ?? null;

            if ($categoryId === null && !empty($categoryIds)) {
                $categoryId = $categoryIds[$index % count($categoryIds)];
            }

            if ($categoryId === null) {
                continue;
            }

            $stmt->execute([
                $categoryId,
                $name,
                $price,
                $image,
                $description,
                $stock,
            ]);
        }
    }

    private static function normalizeProductImages(PDO $db): void
    {
        $products = $db->query('SELECT id, name, image FROM products ORDER BY id ASC')->fetchAll(PDO::FETCH_ASSOC);
        if (empty($products)) {
            return;
        }

        $nameImageMap = [
            'iphone' => '/assets/demo/phone-1.svg',
            'samsung' => '/assets/demo/phone-2.svg',
            'galaxy' => '/assets/demo/phone-2.svg',
            'macbook' => '/assets/demo/laptop-1.svg',
            'asus' => '/assets/demo/laptop-2.svg',
            'dell' => '/assets/demo/laptop-2.svg',
            'sony' => '/assets/demo/audio-1.svg',
            'jbl' => '/assets/demo/audio-2.svg',
            'tai nghe' => '/assets/demo/audio-1.svg',
            'sac' => '/assets/demo/accessory-1.svg',
            'charger' => '/assets/demo/accessory-1.svg',
            'ban phim' => '/assets/demo/accessory-2.svg',
            'chuot' => '/assets/demo/accessory-2.svg',
        ];

        $fallbackPool = [
            '/assets/demo/phone-1.svg',
            '/assets/demo/phone-2.svg',
            '/assets/demo/laptop-1.svg',
            '/assets/demo/laptop-2.svg',
            '/assets/demo/audio-1.svg',
            '/assets/demo/audio-2.svg',
            '/assets/demo/accessory-1.svg',
            '/assets/demo/accessory-2.svg',
        ];

        $updateStmt = $db->prepare('UPDATE products SET image = ? WHERE id = ?');

        foreach ($products as $index => $row) {
            $image = trim((string) ($row['image'] ?? ''));
            if ($image !== '') {
                continue;
            }

            $name = strtolower((string) ($row['name'] ?? ''));
            $resolvedImage = '';

            foreach ($nameImageMap as $keyword => $path) {
                if (str_contains($name, $keyword)) {
                    $resolvedImage = $path;
                    break;
                }
            }

            if ($resolvedImage === '') {
                $resolvedImage = $fallbackPool[$index % count($fallbackPool)] ?? self::DEMO_IMAGE_FALLBACK;
            }

            $updateStmt->execute([$resolvedImage, (int) $row['id']]);
        }
    }
}
