<?php

class ProductModel extends BaseModel
{
    protected string $table = 'products';

    public function getAll(): array
    {
        $rows = $this->fetchAll("SELECT * FROM {$this->table} ORDER BY id DESC");
        return array_map(fn(array $row) => new ProductEntity($row), $rows);
    }

    public function getById(int $id): ?ProductEntity
    {
        $row = $this->fetchOne("SELECT * FROM {$this->table} WHERE id = ?", [$id]);
        return $row ? new ProductEntity($row) : null;
    }

    public function getFeatured(int $limit = 8): array
    {
        $limit = max(1, min(100, $limit));
        $rows = $this->fetchAll("SELECT * FROM {$this->table} ORDER BY id DESC LIMIT {$limit}");
        return array_map(fn(array $row) => new ProductEntity($row), $rows);
    }

    public function getByCategory(int $categoryId): array
    {
        if ($categoryId <= 0) {
            return [];
        }

        $rows = $this->fetchAll(
            "SELECT * FROM {$this->table} WHERE category_id = ? ORDER BY id DESC",
            [$categoryId]
        );

        return array_map(fn(array $row) => new ProductEntity($row), $rows);
    }

    public function search(string $keyword): array
    {
        $keyword = trim($keyword);

        if ($keyword === '') {
            return [];
        }

        $rows = $this->fetchAll(
            "SELECT * FROM {$this->table} WHERE name LIKE ? OR description LIKE ? ORDER BY id DESC",
            ["%{$keyword}%", "%{$keyword}%"]
        );

        return array_map(fn(array $row) => new ProductEntity($row), $rows);
    }

    public function searchByCategory(string $keyword, int $categoryId): array
    {
        $keyword = trim($keyword);

        if ($keyword === '' || $categoryId <= 0) {
            return [];
        }

        $rows = $this->fetchAll(
            "SELECT * FROM {$this->table} WHERE category_id = ? AND (name LIKE ? OR description LIKE ?) ORDER BY id DESC",
            [$categoryId, "%{$keyword}%", "%{$keyword}%"]
        );

        return array_map(fn(array $row) => new ProductEntity($row), $rows);
    }

    public function getLowStockProducts(int $threshold = 5): array
    {
        $threshold = max(0, $threshold);

        $rows = $this->fetchAll(
            "SELECT * FROM {$this->table} WHERE stock <= ? ORDER BY stock ASC, id DESC",
            [$threshold]
        );

        return array_map(fn(array $row) => new ProductEntity($row), $rows);
    }

    public function countFiltered(string $keyword = '', int $categoryId = 0): int
    {
        $keyword = trim($keyword);

        $sql = "SELECT COUNT(*) AS cnt FROM {$this->table} WHERE 1=1";
        $params = [];

        if ($categoryId > 0) {
            $sql .= ' AND category_id = ?';
            $params[] = $categoryId;
        }

        if ($keyword !== '') {
            $sql .= ' AND (name LIKE ? OR description LIKE ?)';
            $params[] = "%{$keyword}%";
            $params[] = "%{$keyword}%";
        }

        $row = $this->fetchOne($sql, $params);
        return isset($row['cnt']) ? (int) $row['cnt'] : 0;
    }

    public function getPaginated(string $keyword = '', int $categoryId = 0, int $page = 1, int $limit = 10): array
    {
        $page = max(1, $page);
        $limit = max(1, min(100, $limit));
        $offset = ($page - 1) * $limit;
        $keyword = trim($keyword);

        $sql = "SELECT * FROM {$this->table} WHERE 1=1";
        $params = [];

        if ($categoryId > 0) {
            $sql .= ' AND category_id = ?';
            $params[] = $categoryId;
        }

        if ($keyword !== '') {
            $sql .= ' AND (name LIKE ? OR description LIKE ?)';
            $params[] = "%{$keyword}%";
            $params[] = "%{$keyword}%";
        }

        $sql .= " ORDER BY id DESC LIMIT {$limit} OFFSET {$offset}";

        $rows = $this->fetchAll($sql, $params);
        return array_map(fn(array $row) => new ProductEntity($row), $rows);
    }

    public function add(array $data): bool
    {
        $product = new ProductEntity($data);
        $errors = $product->validate();

        if (!empty($errors)) {
            return false;
        }

        $id = $this->insert([
            'name' => $data['name'] ?? '',
            'price' => $data['price'] ?? 0,
            'description' => $data['description'] ?? '',
            'image' => $data['image'] ?? '',
            'category_id' => $data['category_id'] ?? 0,
            'stock' => $data['stock'] ?? 0,
        ]);

        return $id > 0;
    }

    public function update(int $id, array $data): bool
    {
        $product = new ProductEntity(array_merge(['id' => $id], $data));
        $errors = $product->validate();

        if (!empty($errors)) {
            return false;
        }

        return parent::update($id, [
            'name' => $data['name'] ?? '',
            'price' => $data['price'] ?? 0,
            'description' => $data['description'] ?? '',
            'image' => $data['image'] ?? '',
            'category_id' => $data['category_id'] ?? 0,
            'stock' => $data['stock'] ?? 0,
        ]);
    }

    public function delete(int $id): bool
    {
        return parent::delete($id);
    }
}
