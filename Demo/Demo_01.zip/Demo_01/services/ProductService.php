<?php

class ProductService
{
    private ProductModel $productModel;
    private CategoryModel $categoryModel;

    public function __construct(ProductModel $productModel, CategoryModel $categoryModel)
    {
        $this->productModel = $productModel;
        $this->categoryModel = $categoryModel;
    }

    private function buildCategoryMap(): array
    {
        $map = [];
        foreach ($this->categoryModel->getAll() as $cat) {
            $map[$cat->getId()] = $cat;
        }
        return $map;
    }

    private function attachCategories(array $products, array $categoryMap): array
    {
        return array_values(array_map(fn(ProductEntity $p) => [
            'product' => $p,
            'category' => $categoryMap[$p->getCategoryId()] ?? null,
        ], $products));
    }

    public function getProductsWithCategory(string $keyword = '', int $categoryId = 0, int $page = 1, int $limit = 10): array
    {
        $keyword = trim($keyword);

        if ($keyword !== '' || $categoryId > 0 || $page > 1) {
            $products = $this->productModel->getPaginated($keyword, $categoryId, $page, $limit);
        } else {
            $products = $this->productModel->getAll();
        }

        if (empty($products)) {
            return [];
        }

        return $this->attachCategories($products, $this->buildCategoryMap());
    }

    public function getFeatured(int $limit = 8): array
    {
        if ($limit < 1) {
            return [];
        }

        $products = $this->productModel->getFeatured($limit);

        if (empty($products)) {
            return [];
        }

        return $this->attachCategories($products, $this->buildCategoryMap());
    }

    public function getProductDetail(int $id): ?array
    {
        $product = $this->productModel->getById($id);

        if ($product === null) {
            return null;
        }

        return [
            'product' => $product,
            'category' => $this->categoryModel->getById($product->getCategoryId()),
        ];
    }

    public function getByCategory(int $categoryId): array
    {
        if ($categoryId <= 0) {
            return [];
        }

        $products = $this->productModel->getByCategory($categoryId);

        if (empty($products)) {
            return [];
        }

        return $this->attachCategories($products, $this->buildCategoryMap());
    }

    public function getCategoryById(int $id): ?CategoryEntity
    {
        return $this->categoryModel->getById($id);
    }

    public function searchAndFilter(string $keyword, int $categoryId = 0): array
    {
        $keyword = trim($keyword);

        if ($keyword === '' && $categoryId <= 0) {
            return [];
        }

        if ($keyword !== '' && $categoryId > 0) {
            $products = $this->productModel->searchByCategory($keyword, $categoryId);
        } elseif ($keyword !== '') {
            $products = $this->productModel->search($keyword);
        } else {
            $products = $this->productModel->getByCategory($categoryId);
        }

        if (empty($products)) {
            return [];
        }

        return $this->attachCategories($products, $this->buildCategoryMap());
    }

    public function getAllCategories(): array
    {
        return $this->categoryModel->getAll();
    }

    public function countProductsByCategory(int $categoryId): int
    {
        if ($categoryId <= 0) {
            return 0;
        }

        return count($this->productModel->getByCategory($categoryId));
    }

    public function countProducts(): int
    {
        return $this->productModel->count();
    }

    public function getLowStockProducts(int $threshold = 5): array
    {
        $products = $this->productModel->getLowStockProducts($threshold);

        if (empty($products)) {
            return [];
        }

        return $this->attachCategories($products, $this->buildCategoryMap());
    }

    public function countProductPages(string $keyword = '', int $categoryId = 0, int $limit = 10): int
    {
        $limit = max(1, $limit);
        $total = $this->productModel->countFiltered($keyword, $categoryId);

        return $total > 0 ? (int) ceil($total / $limit) : 0;
    }

    public function validateProductData(array $data): array
    {
        $entity = new ProductEntity($data);
        return $entity->validate();
    }

    public function createProduct(array $data): bool
    {
        return $this->productModel->add($data);
    }

    public function updateProduct(int $id, array $data): bool
    {
        return $this->productModel->update($id, $data);
    }

    public function deleteProduct(int $id): bool
    {
        return $this->productModel->delete($id);
    }

    public function getProductById(int $id): ?ProductEntity
    {
        return $this->productModel->getById($id);
    }
}
