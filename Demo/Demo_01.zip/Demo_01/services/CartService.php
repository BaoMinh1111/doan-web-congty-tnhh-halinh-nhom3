<?php

class CartService
{
    private ProductModel $productModel;
    private InventoryModel $inventoryModel;
    private PromotionModel $promotionModel;
    private string $sessionKey = 'cart';

    public function __construct()
    {
        $this->productModel   = new ProductModel();
        $this->inventoryModel = new InventoryModel();
        $this->promotionModel = new PromotionModel();

        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        if (!isset($_SESSION[$this->sessionKey])) {
            $_SESSION[$this->sessionKey] = [];
        }
    }

    private function response(bool $success, string $message, mixed $data = null): array
    {
        return [
            'success' => $success,
            'message' => $message,
            'data'    => $data,
        ];
    }

    public function all(): array
    {
        return $_SESSION[$this->sessionKey];
    }

    public function add(int $productId, int $quantity): array
    {
        try {
            if ($productId <= 0 || $quantity <= 0) {
                throw new Exception('Du lieu khong hop le');
            }

            $product = $this->productModel->getById($productId);
            if ($product === null) {
                throw new Exception('Khong tim thay san pham');
            }

            $inventory = $this->inventoryModel->getByProductId($productId);
            $stock = $inventory?->getQuantity() ?? (int) ($product->getStock() ?? 0);

            if (isset($_SESSION[$this->sessionKey][$productId])) {
                $newQty = $_SESSION[$this->sessionKey][$productId]['quantity'] + $quantity;
                if ($newQty > $stock) {
                    throw new Exception('So luong vuot qua ton kho');
                }

                $_SESSION[$this->sessionKey][$productId]['quantity'] = $newQty;
            } else {
                if ($quantity > $stock) {
                    throw new Exception('Khong du hang trong kho');
                }

                $_SESSION[$this->sessionKey][$productId] = [
                    'product_id' => $productId,
                    'name'       => $product->getName(),
                    'price'      => $product->getPrice(),
                    'quantity'   => $quantity,
                ];
            }

            return $this->response(true, 'Them thanh cong', $_SESSION[$this->sessionKey][$productId]);
        } catch (Throwable $e) {
            return $this->response(false, $e->getMessage());
        }
    }

    public function remove(int $productId): array
    {
        if (!isset($_SESSION[$this->sessionKey][$productId])) {
            return $this->response(false, 'San pham khong co trong gio');
        }

        unset($_SESSION[$this->sessionKey][$productId]);
        return $this->response(true, 'Da xoa san pham');
    }

    public function update(int $productId, int $quantity): array
    {
        try {
            if (!isset($_SESSION[$this->sessionKey][$productId])) {
                throw new Exception('Khong co san pham trong gio');
            }

            if ($quantity === 0) {
                return $this->remove($productId);
            }

            if ($quantity < 0) {
                throw new Exception('So luong khong hop le');
            }

            $inventory = $this->inventoryModel->getByProductId($productId);
            $stock = $inventory?->getQuantity() ?? 0;
            if ($quantity > $stock) {
                throw new Exception('Vuot qua so luong trong kho');
            }

            $_SESSION[$this->sessionKey][$productId]['quantity'] = $quantity;

            return $this->response(true, 'Cap nhat thanh cong', $_SESSION[$this->sessionKey][$productId]);
        } catch (Throwable $e) {
            return $this->response(false, $e->getMessage());
        }
    }

    public function clear(): array
    {
        $_SESSION[$this->sessionKey] = [];
        return $this->response(true, 'Da xoa toan bo gio hang');
    }

    public function getTotal(): array
    {
        $subtotal = 0.0;

        foreach ($_SESSION[$this->sessionKey] as $item) {
            $subtotal += (float) $item['price'] * (int) $item['quantity'];
        }

        $discount = 0.0;

        return $this->response(true, 'Tinh tong thanh cong', [
            'subtotal' => $subtotal,
            'discount' => $discount,
            'total'    => $subtotal - $discount,
        ]);
    }
}
