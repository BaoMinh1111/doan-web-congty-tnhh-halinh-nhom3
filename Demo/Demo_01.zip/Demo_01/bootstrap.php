<?php

if (!defined('BASE_PATH')) {
    define('BASE_PATH', __DIR__);
}

if (!defined('APP_ENV')) {
    define('APP_ENV', 'development');
}

if (APP_ENV === 'development') {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
}

date_default_timezone_set('Asia/Ho_Chi_Minh');

require_once BASE_PATH . '/config/Database.php';
require_once BASE_PATH . '/database/DemoDataSeeder.php';

DemoDataSeeder::seedIfNeeded();

require_once BASE_PATH . '/helpers/ValidatorHelper.php';
require_once BASE_PATH . '/helpers/SessionHelper.php';
require_once BASE_PATH . '/helpers/UploadHelper.php';
require_once BASE_PATH . '/helpers/AdminMiddleware.php';

require_once BASE_PATH . '/entities/CategoryEntity.php';
require_once BASE_PATH . '/entities/ProductEntity.php';
require_once BASE_PATH . '/entities/UserEntity.php';
require_once BASE_PATH . '/entities/AdminEntity.php';
require_once BASE_PATH . '/entities/CustomerEntity.php';
require_once BASE_PATH . '/entities/InventoryEntity.php';
require_once BASE_PATH . '/entities/PromotionEntity.php';
require_once BASE_PATH . '/entities/OrderItemEntity.php';
require_once BASE_PATH . '/entities/OrderEntity.php';

require_once BASE_PATH . '/models/BaseModel.php';
require_once BASE_PATH . '/models/CategoryModel.php';
require_once BASE_PATH . '/models/ProductModel.php';
require_once BASE_PATH . '/models/UserModel.php';
require_once BASE_PATH . '/models/AdminModel.php';
require_once BASE_PATH . '/models/CustomerModel.php';
require_once BASE_PATH . '/models/InventoryModel.php';
require_once BASE_PATH . '/models/PromotionModel.php';
require_once BASE_PATH . '/models/OrderModel.php';
require_once BASE_PATH . '/models/OrderDetailModel.php';

require_once BASE_PATH . '/services/AuthService.php';
require_once BASE_PATH . '/services/ProductService.php';
require_once BASE_PATH . '/services/CartService.php';
require_once BASE_PATH . '/services/OrderService.php';

require_once BASE_PATH . '/controller/BaseController.php';
require_once BASE_PATH . '/controller/HomeController.php';
require_once BASE_PATH . '/controller/ProductController.php';
require_once BASE_PATH . '/controller/CartController.php';
require_once BASE_PATH . '/controller/AdminController.php';
